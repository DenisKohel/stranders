import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import commonjs from 'vite-plugin-commonjs';
export default defineConfig({
  root: 'client',
  plugins: [vue(),commonjs()],
  build: {
    outDir: '../public',
  },
  server: {
    port: 8080,
  },
  publicDir: 'public',
  css: {
    modules: {
      localsConvention: 'camelCaseOnly',
    },
  },
});