class Item {
    constructor(id, name, data) {
      this.id = id;
      this.name = name;
      Object.assign(this,data);
    
  
    this.use = function(player, game) {
      player.attack(game)
    }
     
    this.onSelect = function(player){
      if (this.stats){
        for (let key in this.stats){
          player[key] += this.stats[key]}
      }
    }
    this.onDeselect = function(player){
      if (this.stats){
        for (let key in this.stats){
          player[key] -= this.stats[key]}
      }
    }
  }
  }

export class ItemList {}
  ItemList.byId = new Map()
  ItemList.byName = new Map()
  ItemList.add = function(item){
    ItemList.byId.set(item.id,item)
    ItemList.byName.set(item.name,item)
  }
  ItemList.getItemById = function(id){
    return Object.assign({},ItemList.byId.get(id))
  }
  ItemList.getItemByName = function(id){
    return Object.assign({},ItemList.byName.get(id))
  }
  



  const woodItem = new Item(1,"wood",{})
  ItemList.add(woodItem)
  const stoneItem = new Item(2,"stone",{})
  ItemList.add(stoneItem)
  const woodenSwordItem = new Item(3,"woodenSword",{})
  woodenSwordItem.stats = {attackWidth: 140,damage: 2}
  ItemList.add(woodenSwordItem)
 