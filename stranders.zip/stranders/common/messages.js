import nengi from "nengi"
export class Chat{
    constructor(text){
        this.text = text
    }
}
Chat.protocol = {text: nengi.String}

export class Identity{
    constructor(nid,border){
        this.nid = nid
        this.borderWidth = border.width
        this.borderHeight = border.height
    }
}
Identity.protocol = {nid: nengi.Number,
borderWidth: nengi.Number,
borderHeight: nengi.Number}

export class Fps{
    constructor(fps){
        this.fps = Math.round(fps)
    }
}
Fps.protocol = {fps: nengi.Number}

export class Animate{
    constructor(entity,dataValue){
        this.x = entity.x
        this.y = entity.y
        this.id = entity.nid
        this.dataValue = dataValue
    
    }
}
Animate.protocol = {id: nengi.Number,dataValue: nengi.Number}

export class InventoryChange{
    constructor(slot,id,count){
        this.id = id
        this.slot = slot
        this.count = count
    
    }
}
InventoryChange.protocol = {id: nengi.Number,count: nengi.Number, slot: nengi.Number}

export class PlayerHp{
    constructor(hp,maxHp){
        this.hp = hp
        this.maxHp = maxHp
    }
}
PlayerHp.protocol = {hp: nengi.Number, maxHp: nengi.Number}