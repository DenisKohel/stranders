import * as Comps from "./components.js"
import nengi from "nengi"
import { Uti } from "./Uti.js"
import { eventer } from "./eventer.js"
import { Animate } from "./messages.js"
import { ItemList } from './items';

class Entity{
    constructor(data){
        this.isAlive = true
        this.spawnBlockMultiplier = 1
        
        this.x = 100
        this.y = 100
        this.rotation = 0
        this.scale = 6
        
        Object.assign(this,data) // TODO: change to variables
        
        this.updatable = false
        this.updateComps = [{update:function(){return}}]
    }
    setPos(x,y){this.x = x;this.y = y;eventer.emit("posChanged",this)}
    changePos(x,y){this.setPos(this.x + x,this.y + y)}
    get spawnBlockRadius(){return this.spawnBlockMultiplier*this.shape.radius}
    update(delta,game){for(let i in this.updateComps){this.updateComps[i].update(this,delta,game)}}
    addComp(component,data){
    let comp = new component(data,this)
    this[comp.name] = comp
    }
}

export class Player extends Entity{
    constructor(){
        super({})
        
        this.updatable = true
        this.addComp(Comps.Physics,{speed: 400,pushable:true})
        this.addComp(Comps.Circle,{radius: 5})
        this.addComp(Comps.Inventory,{size: 6})
        mixin(this,new Comps.Hittable({hp: 25}))
        mixin(this,new Comps.Attacker({}))
        this.control = {dir:{x:0,y:0}}
        this.clicking = false;this.lastTimeAttacking = false
        
        
        this.selectedSlot = 0
        
        
        //setTimeout(()=>this.inventory.addItems(ItemList.getItemByName("woodenSword"),1),4000) //
    }
    update(delta,game){super.update(delta,game)
        if(!this.clicking){return}
        if(Date.now() - this.lastTimeAttacking < this.attackRate){return}
        //this.lastTimeAttacking = Date.now()
        if(this.selectedItem){this.selectedItem.use(this,game)}
        else{this.attack(game)}
    }
    
    selectItem(item){
         
        if(item){
            if(this.selectedItemId == item.id){return}
            if(this.selectedItem){this.selectedItem.onDeselect(this)}
            this.selectedItem = item
            this.selectedItemId= item.id
        item.onSelect(this)
    
    }
        else{
            if(this.selectedItem){this.selectedItem.onDeselect(this)}
            this.selectedItem = undefined
            this.selectedItemId = 0}
        //console.log(this.selectedItemId)
    }
    selectSlot(slot){
        if(this.selectedSlot == slot){return}
        this.selectedSlot = slot
        let items = this.inventory.getItems(slot)
        
        if(items){this.selectItem(items.item)}
        else{this.selectItem(undefined)}
    }
}
Player.protocol = {x:{type: nengi.Number, interp: true},
y:{type: nengi.Number, interp: true},
rotation:{type: nengi.RotationFloat32, interp: true},
//scale:{type: nengi.Number, interp: true},
selectedItemId:{type: nengi.Number}
}

export class Tree extends Entity{
    constructor(){
        super({scale:Uti.rndRange(7,8.7),rotation:Math.random()*Math.PI*2})
        //this.addComp(Comps.Polygon,{points:[[-10.5,-10.5],[10.5,-10.5],[10.5,10.5],[-10.5,10.5]]})
        this.addComp(Comps.Rectangle,{width:22,height:22})
       
        
        mixin(this,new Comps.HittableResource({hp:Math.round(this.scale)*7}))
    }
    
}
Tree.protocol = {x:{type: nengi.Number, interp: true},
y:{type: nengi.Number, interp: true},
rotation:{type: nengi.RotationFloat32, interp: true},
scale:{type: nengi.Number, interp: true},
}

export class Zombie extends Entity{
    constructor(){
        super({scale:7})
        this.spawnBlockMultiplier = 50
        this.updatable = true
        this.addComp(Comps.Physics,{speed: 300,pushable:true})
        this.addComp(Comps.Circle,{radius: 5})
        this.addComp(Comps.AIController,{state: "chase"})
        mixin(this,new Comps.Hittable({hp:15}))
        mixin(this,new Comps.Attacker({attackWidth: 100, attackHeight: 110, attackRate: 900,damage: 7}))
    }
    
}
Zombie.protocol = {x:{type: nengi.Number, interp: true},
y:{type: nengi.Number, interp: true},
rotation:{type: nengi.RotationFloat32, interp: true},
}


function mixin(target, sourceInstance) {
    // Copy the instance properties to the target instance
    Object.assign(target, sourceInstance);
  
    // Copy the prototype methods to the target instance
    const sourcePrototype = Object.getPrototypeOf(sourceInstance);
    const propertyNames = Object.getOwnPropertyNames(sourcePrototype);
  
    for (let i = 0; i < propertyNames.length; i++) {
      const name = propertyNames[i];
      if (name !== "constructor") {
        target[name] = sourceInstance[name];
      }
    }
  }