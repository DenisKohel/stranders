const EventEmitter = require('events');
export const eventer = new EventEmitter();
