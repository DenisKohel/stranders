export class Uti{}
Uti.rndRange = function(min,max){return Math.random()*(max-min) + min}
Uti.flattenArray = function(array){
    let flatArray = []
    for (let a in array){
        for(let b in array[a]){flatArray.push(array[a][b])}
    }
    return flatArray
}
Uti.getDistanceSq = function(p1,p2){
  return ((p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y))

}
Uti.getDistance = function(p1,p2){
  return Math.sqrt(Uti.getDistanceSq(p1,p2))
}


Uti.interpolate = function(i, m, k) {
  
    const ip = (i / m) * 100;
    let pk = { p: 0, v: 0 }, nk = { p: 100, v: 0 };
  
    for (const kf of k) {
      if (ip === kf.p) return kf.v;
      if (ip < kf.p) { nk = kf; break; }
      pk = kf;
    }
  
    return pk.v + (ip - pk.p) / (nk.p - pk.p) * (nk.v - pk.v);
  }

  Uti.rgbToHex = function(rgbArray) {
    const r = rgbArray[0] << 16;
    const g = rgbArray[1] << 8;
    const b = rgbArray[2];
    return r + g + b;
  }