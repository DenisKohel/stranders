const SAT = require('sat')
import { Animate } from "./messages.js"
import { eventer } from './eventer'
import { Player } from "./entities.js"
import { ItemList } from './items';
export class Physics {
    constructor({ speed, pushable, damping }, that) {
      this.name = "phys";
      this.dir = { x: 0, y: 0 };
      this.pushable = pushable || false;
      this.vel = { x: 0, y: 0 };
      this.speed = speed || 10;
      this.damping = damping || 0.5;
      this.oldX = this.oldY = 0;
  
      that.updateComps.push(this);
    }
  
    applyImpulse(impulse) {
        this.vel.x += impulse.x;
        this.vel.y += impulse.y;
    }
  
    update(that, delta, game) {
      this.dir.x = that.control.dir.x;
      this.dir.y = that.control.dir.y;
  
      this.vel.x += this.dir.x * this.speed * delta;
      this.vel.y += this.dir.y * this.speed * delta;
  
      // Apply damping to the velocity
      this.vel.x *= this.damping;
      this.vel.y *= this.damping;
  
      let x = that.x + this.vel.x;
      let y = that.y + this.vel.y;
  
      if (Math.abs(x - this.oldX) >= 1 || Math.abs(y - this.oldY) >= 1) {
        that.setPos(x, y);
        let entities = game.grid.getNearEntities(that, 1);
  
        let results = that.shape.checkCollisions(entities);
        if (results[0]) {
          for (let i in results) {
            let result = results[i];
            let entity = result.entity;
  
            if (entity.phys && entity.phys.pushable) {
              that.changePos(-result.overlapV.x * 0.5, -result.overlapV.y * 0.5);
              entity.changePos(result.overlapV.x * 0.5, result.overlapV.y * 0.5);
            } else {
              that.changePos(-result.overlapV.x, -result.overlapV.y);
            }
          }
        }
      }
      this.oldX = x;
      this.oldY = y;
    }
  }

export class AIController{
    constructor(data,that){
        this.name = "control"
        this.dir = {x:0, y:0}
        this.viewDistance = 900
        this.viewCone = Math.PI

        this.attackDistance = 155
        this.nextChange = Date.now()
        this.walkDuration = 0
        this.pauseDuration = 0
        this.walking = true

        this.chaseState = states.chaseAndAttack
        this.idleState = states.idleThenChase
        this.setState(this.idleState)
        that.updateComps.push(this)
    }
    setState(state){
        this.update = state.update
        if(state.onSet)(state.onSet.call(this))
    }
    
}

const states = {}
states.chase = {update: function(that,delta,game){
    const nearbyEntities = game.getNear(that);
    let target = this.target
    //console.log(target.x)
    if (!target || !target.isAlive) {
        this.setState(this.idleState)
        return false}
    
    let sight = checkSight(that,target,nearbyEntities)
    if(sight){
        this.dir.x = sight.dirX / sight.distance || 0;
        this.dir.y = sight.dirY / sight.distance || 0;
        that.rotation = Math.atan2(this.dir.y, this.dir.x);
        return sight
        }
        else{
        this.dir.x = 0;
        this.dir.y = 0;
        this.setState(this.idleState)
        return false
        }
    
}
}
states.chaseAndAttack = {update: function(that,delta,game){
    let sight = states.chase.update.call(this, that, delta, game)
    if (!sight || sight.distance > this.attackDistance){return}
    if (Date.now() - that.lastTimeAttacking > that.attackRate) {
    that.lastTimeAttacking = Date.now();
    
    // Stop the enemy for 200 ms
    this.setState(states.wait);
    setTimeout(() => {
        // Charge the enemy with twice the speed for 300 ms
        that.phys.speed *= 1.5;
        this.setState(this.chaseState);
        setTimeout(() => {
            // Enemy attacks and stops for 200 ms
            that.attack(game);
            this.setState(states.wait);
            setTimeout(() => {
                // Enemy starts moving again with half the speed
                that.phys.speed /= 1.5;
                this.setState(this.chaseState);
            }, 250);
        }, 450);
    }, 250);
} 
}}
states.idle = {
    onSet: function(){this.walking = false},
    update: function(that, delta, game) {
        const currentTime = Date.now();
    
        if (this.nextChange <= currentTime) {
          if (this.walking) {
            this.walkDuration = Math.random() * 1500 + 10; // 1s to 3s
            this.nextChange = currentTime + this.walkDuration;
            this.walking = false;
            const randomRotation = Math.random() * 2 * Math.PI; // Random rotation in radians
            this.dir.x = Math.cos(randomRotation);
            this.dir.y = Math.sin(randomRotation);
            that.rotation = randomRotation
        } else {
            this.pauseDuration = Math.random() * 1500 + 500; // 1s to 3s
            this.nextChange = currentTime + this.pauseDuration;
            this.walking = true;
            this.dir.x = 0;
            this.dir.y = 0;
          }
        }
    
      }
  };  
  
states.idleThenChase = {
    update: function (that, delta, game) {
    states.idle.update.call(this, that, delta, game);
    
    const nearbyEntities = game.getNear(that);
    const target = nearbyEntities.find((entity) => entity instanceof Player);
    if(!target){return}
    if (checkSight(that,target,nearbyEntities)){
        this.target = target
        this.setState(this.chaseState)}
    },
  };
  states.wait = {
    update: function(that, delta, game){
        this.dir.x = 0
        this.dir.y = 0
    }
  }
  function getRandomDirection(min, max) {
    return Math.random() * (max - min) + min;
  }
function checkSight(e1,e2,nearbyEntities){
    let dirX = e2.x - e1.x;
    let dirY = e2.y - e1.y;
    const distance = Math.sqrt(dirX ** 2 + dirY ** 2);
    
    if (distance <= e1.control.viewDistance && (inViewCone(e1,e2) && raycast(e1,e2,nearbyEntities) == e2) || distance <= e1.shape.r * 3)
    {return {distance: distance, dirX: dirX, dirY: dirY}}
    else{return false}
}

function raycast(e1,e2,nearEntities){
    //let nearEntities = game.getNear(e1)
        let minDistanceSqr = Infinity
        let closestEntity = null
        let rotation = Math.atan2(e2.y - e1.y,e2.x - e1.x)
        let width = Math.pow(e1.x - e2.x,2) + Math.pow(e1.y - e2.y,2)
        let ray = new Rectangle({width: width, height: 2}, // TODO: separate everything
        {rotation: rotation, x:e1.x, y:e1.y,scale:1})
       let collisions = ray.checkCollisions(nearEntities)
        for (let i in collisions){
            let entity = collisions[i].entity
            if(entity == e1){continue}
           let distanceSqr = Math.pow(e1.x - entity.x,2) + Math.pow(e1.y - entity.y,2)
           if (distanceSqr < minDistanceSqr){
            minDistanceSqr = distanceSqr
            closestEntity = entity
           }
        }
        
        return closestEntity
}

function inViewCone(that, player) {
    const dx = player.x - that.x;
    const dy = player.y - that.y;
    
    const angleBetween = Math.atan2(dy, dx);
    const halfConeAngle = that.control.viewCone / 2;
    
    const lowerBound = normalizeAngle(that.rotation - halfConeAngle);
    const upperBound = normalizeAngle(that.rotation + halfConeAngle);

    const angleBetweenNormalized = normalizeAngle(angleBetween);

    if (lowerBound <= upperBound) {
        return angleBetweenNormalized >= lowerBound && angleBetweenNormalized <= upperBound;
    } else {
        // When the cone spans the 0 radian line
        return angleBetweenNormalized >= lowerBound || angleBetweenNormalized <= upperBound;
    }
}
function normalizeAngle(angle) {
    while (angle < 0) {
        angle += Math.PI * 2;
    }
    while (angle > Math.PI * 2) {
        angle -= Math.PI * 2;
    }
    return angle;
}

export class Attacker{
    constructor(data){
        this.attackWidth = data.attackWidth || 70
        this.attackHeight = data.attackWidth || 100
        this.attackRate = data.attackRate || 600
        this.damage = data.damage || 1
        this.knockback = data.knockback || 60
        this.lastTimeAttacking = 0
    }
    attack(game){
        game.instance.addLocalMessage(new Animate(this,2))
        this.lastTimeAttacking = Date.now()
        //event emitter
        let length = 50
        let x = this.x + Math.cos(this.rotation)*length
        let y = this.y + Math.sin(this.rotation)*length
        let hurtBox = new Rectangle({width: this.attackWidth, height: this.attackHeight}, // TODO: separate everything
        {rotation: this.rotation, x:x, y:y,scale:1})
        let nearEntities = game.getNear(this)
       let collisions = hurtBox.checkCollisions(nearEntities)
        for (let i in collisions){
            let entity = collisions[i].entity
            if(entity == this){continue}
           entity.hit(game,this)
        }
    }
}

export class Shape{
    constructor({},that){
        this.name = "shape"
        this.that = that
    }
    updatePos(){this.pos.x = this.that.x;this.pos.y = this.that.y}
    testCollision(entity){
    this.updatePos()
    let shape = entity.shape
    shape.updatePos()
    let test = shape.tests[this.testForMe]
    let response = new SAT.Response();
    let collided = test(this, shape, response)
    
    return [collided,response]
    }
    checkCollisions(entities){
        let results = []
    for (let i in entities){let entity = entities[i]
        if(!entity.shape){continue}
        if (entity.shape == this){continue;}
        let result = this.testCollision(entity)
        
        if (result[0] == true){result[1].entity = entity;results.push(result[1])}
    }
    return results
    }
    }

export class Circle extends Shape{
constructor({radius},that){
    super({},that)
    this.testForMe = 0 
    this.tests = [SAT.testCircleCircle,SAT.testPolygonCircle]
    
    let circle = new SAT.Circle(new SAT.Vector(that.x,that.y), radius*that.scale)
    
    Object.assign(this,circle)
}
}

export class Polygon extends Shape{
    constructor({points},that){
        super({},that)
        this.testForMe = 1
        this.tests = [SAT.testCirclePolygon,SAT.testPolygonPolygon]
        
        let vectors = []
        for (let i in points){let point = points[i]
            vectors[i] = new SAT.Vector(point[0],point[1]).scale(that.scale)}
        let polygon = new SAT.Polygon(new SAT.Vector(that.x,that.y),vectors);
         polygon.pos.x = that.x;polygon.pos.y = that.y
          polygon.setAngle(that.rotation)
          
        Object.assign(this,polygon)
    }
    }

    export class Rectangle extends Shape{
        constructor({width,height},that){
            super({},that)
            this.testForMe = 1
            this.tests = [SAT.testCirclePolygon,SAT.testPolygonPolygon]
            
            let rectangle = new SAT.Box(new SAT.Vector(that.x,that.y), width*that.scale, height*that.scale)
            rectangle = rectangle.toPolygon()
            rectangle.setOffset(new SAT.Vector(-width*that.scale*0.5,-height*that.scale*0.5))
            rectangle.setAngle(that.rotation)
            this.radius = width*that.scale*0.5
            Object.assign(this,rectangle)
        }
        }

    export class HP{
        constructor({hp}){
            this.hp = hp || 20
            this.maxHp = this.hp
            this.removeHp = function(amount){
                this.hp -= amount
                if(this.hp <= 0){this.hp = 0
                    this.die()}
                eventer.emit("hpChange",this)

            }
            this.die = function(){
                
                eventer.emit("death",this)
            }
        }
    }

    export class Inventory{
        constructor({size},that){
            this.name = "inventory"
            this.that = that
            this.size = size || 6
            this.slots = []

        }
        setItems(slot,item,count){
            if(slot > this.size || slot < 0){console.log("!! slot "+slot+" doesn't exist");return}
            
            this.slots[slot] = {item: item, count: count}
            eventer.emit("inventoryChange",{player:this.that,slot:slot})
            //console.log(slot + " : " + this.that.selectedSlot)
            if(this.that.selectedSlot == slot){this.that.selectItem(this.slots[slot].item)}
        }
        clear(slot){
            this.slots[slot] = undefined
            if(this.that.selectedSlot == slot){this.that.selectItem(undefined)}
            eventer.emit("inventoryChange",{player:this.that,slot:slot})
        }
        addItems(item,count){
            for(let i = 0;i < this.size; i++){
                let slot = this.slots[i]
                if(slot == undefined){this.setItems(i,item,count);return true}
                if(slot.item.id == item.id){this.setItems(i,item,count + slot.count);return true } // TODO: Stacks
            }
            // drop item

            return false
        }
        getItems(slot) {
            
            if(this.slots[slot]){return this.slots[slot]}
            else {return null}
          }
    }


    export class Hittable{
        constructor(data){
        Object.assign(this,new HP(data))
        }
            hit(game,entity){
                game.instance.addLocalMessage(new Animate(this,1))
                let dirX = Math.cos(entity.rotation)
                let dirY = Math.sin(entity.rotation)
                this.phys.applyImpulse({x: dirX*entity.knockback, y: dirY*entity.knockback})
                this.removeHp(entity.damage)
                
            }
        }

    export class HittableResource extends Hittable{
        constructor(data){super(data)}
               hit(game,entity){
                game.instance.addLocalMessage(new Animate(this,entity.rotation))
                this.removeHp(2)
                if(entity instanceof Player){
                    entity.inventory.addItems(ItemList.getItemByName("wood"),1)
                    entity.inventory.addItems(ItemList.getItemByName("stone"),1)
                    entity.inventory.addItems(ItemList.getItemByName("woodenSword"),1)
                } 
            
        }
        }

        
        