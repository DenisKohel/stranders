import nengi from 'nengi'
import {Animate, Chat,Fps,Identity, InventoryChange, PlayerHp} from "./messages.js"
import { PlayerInput,Rotation,Clicking, SelectSlot } from './commands.js'
import * as Entities from "./entities.js"


const nengiConfig = {
    UPDATE_RATE: 20, 

    ID_BINARY_TYPE: nengi.UInt16,
    TYPE_BINARY_TYPE: nengi.UInt8, 

    ID_PROPERTY_NAME: 'nid',
    TYPE_PROPERTY_NAME: 'ntype', 

    USE_HISTORIAN: true,
    HISTORIAN_TICKS: 40,

    protocols: {
        entities: [
            ["Player",Entities.Player],
            ["Tree",Entities.Tree],
            ["Zombie",Entities.Zombie]
        ],
        localMessages: [["Animate",Animate]],
        messages: [
            ["Chat",Chat],
            ["Identity",Identity],
            ["Fps",Fps],
            ["InventoryChange",InventoryChange],
            ["PlayerHp",PlayerHp]
        ],
        commands: [
            ["PlayerInput",PlayerInput],
            ["Rotation",Rotation],
            ["Clicking",Clicking],
            ["SelectSlot",SelectSlot]
        ],
        basics: []
    }
}

export default nengiConfig