require = require('esm')(module/*, options*/)
module.exports = require('./server/main.js')
