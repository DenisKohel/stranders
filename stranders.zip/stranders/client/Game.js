import nengiConfig from "../common/nengiConfig.js"
import nengi from "nengi"
import { Client } from "./Client.js"
import * as Graphs from "./graphs.js"
import { Display } from './Display.js';
import Input from "./Input.js";
import { PlayerInput, Rotation, Clicking, SelectSlot } from "../common/commands.js";
import { Camera } from "./Camera.js";
import { Player } from './graphs.js';
import { Joystick } from './joystick';
import { eventer } from "../common/eventer.js";
import { ItemList } from "../common/items.js";
import { Uti } from './../common/Uti';
import * as PIXI from "pixi.js"

const TWEEN = require('@tweenjs/tween.js')

export class Game{
constructor(){
    this.worldTime = 200;this.worldTimeMax = 600
    this.processedInput = {rotation:0}
    if(detectMobile()){this.joystick1 = new Joystick()
        this.processInput = processMobileInput

        window.addEventListener("pointerdown",()=>{
            this.processedInput.clicking = true
            this.client.addCommand(new Clicking(true))
        })
        window.addEventListener("pointerup",()=>{
            this.processedInput.clicking = false
            this.client.addCommand(new Clicking(false))
        })
    
    }
        else{this.processInput = processDesktopInput;listenForMouse(this)}
    
    const graphs = this.graphs = []
    this.graphsToDelete = []
    const client = this.client = new Client({port: 8079})

    this.inventory = [{},{},{},{},{},{},{}]
    
    this.camera = new Camera()
    this.player;let playerID = 0
    let fpsCounter = document.getElementById("fps-counter") //
    let avg = 0,n = 0,sum = 0;client.on("message::Fps",(data)=>{sum+= data.fps;n++;avg = sum/n
    fpsCounter.innerHTML = "S " + data.fps + " ("+Math.round(avg) +")" })
    client.on("message::Identity",(data)=>{playerID = data.nid
        console.log("identified")
    this.camera.setBorder(data.borderWidth,data.borderHeight)})
    client.on("create",(data)=>{let graph = new Graphs[data.protocol.name](data)
    if(data.nid == playerID){this.player = graph
        this.camera.setFollowing(this.player.entity)
    } 
    console.log(data.protocol.name)
    this.addGraph(graph)
    }) 
    client.on("update",(data)=>{let graph = graphs[data.nid]
    graph.entity[data.prop] = data.value})
    client.on("delete",(nid)=>{this.graphsToDelete[nid] = this.graphs[nid]})
    client.on("message::Animate",(data)=>{
        this.graphs[data.id].animate(data.dataValue)})
    client.on("message::InventoryChange",(data)=>{
        this.inventory[data.slot] = {item:{id: data.id, name: ItemList.getItemById(data.id).name}, count: data.count}
    eventer.emit("playerInventory",this.inventory)})
    client.on("message::PlayerHp",(data)=>{
        eventer.emit("playerHp",data)
    })
    
    this.zoomin = 1;window.addEventListener("P",(e)=>{this.zoomin += e.detail[0]/200})
    window.addEventListener("1",(e)=>{this.client.addCommand(new SelectSlot(0));eventer.emit("selectSlot",0)})
    window.addEventListener("2",(e)=>{this.client.addCommand(new SelectSlot(1));eventer.emit("selectSlot",1)})
    window.addEventListener("3",(e)=>{this.client.addCommand(new SelectSlot(2));eventer.emit("selectSlot",2)})
    window.addEventListener("4",(e)=>{this.client.addCommand(new SelectSlot(3));eventer.emit("selectSlot",3)})
    window.addEventListener("5",(e)=>{this.client.addCommand(new SelectSlot(4));eventer.emit("selectSlot",4)})
    window.addEventListener("6",(e)=>{this.client.addCommand(new SelectSlot(5));eventer.emit("selectSlot",5)})
    window.addEventListener("7",(e)=>{this.client.addCommand(new SelectSlot(6));eventer.emit("selectSlot",6)})
    
    
}
update(delta){
    updateDayLight(delta,this)

    this.client.readNetworkAndEmit()
    this.processedInput = this.processInput(this.processedInput)
    
    this.camera.update()
    Display.current.stage.pivot.set(this.camera.x,this.camera.y)
    for (let i in this.graphs){this.graphs[i].update(delta,this.camera)}
    predictPlayer(this.player,this)
    TWEEN.update(/* delta */)
    
    for (let nid in this.graphsToDelete){delete this.graphs[nid]
    console.log("deleted " + this.graphsToDelete[nid])}

    
    this.client.update()


    Display.current.stage.scale.x = this.zoomin
    Display.current.stage.scale.y = this.zoomin
    /* Display.current.stage.position.x -= this.zoomin
    Display.current.stage.position.y -= this.zoomin */

    //Game.current = this
}

addGraph(graph){
    this.graphs[graph.entity.nid] = graph
}

}

// /// ///

function processMobileInput(processedInput){
    if(this.joystick1.checkChange()){this.client.addCommand(new PlayerInput(this.joystick1.dir/* ,delta */))
        this.client.addCommand(new Rotation(this.joystick1.angle))
    return {dir: this.joystick1.dir, rotation: this.joystick1.angle}} // TODO: make joystick2
    return processedInput
}
function processDesktopInput(processedInput){
    if (Input.current.checkChange() == true){
        let keys = Input.current.keys
    let moveX = keys.D.down - keys.A.down
    let moveY = keys.S.down - keys.W.down
    let hypotenuse = Math.sqrt(moveX*moveX + moveY*moveY)
    let dir = {x: moveX / hypotenuse || 0, y: moveY / hypotenuse || 0}
       this.client.addCommand(new PlayerInput(dir/* ,delta */))
    return {dir: dir, rotation: processedInput.rotation}
}
return processedInput
}

function listenForMouse(game){
    
    /* Display.current.renderer.view. */let onmousemove = ()=>{
// event emitter
        if(!game.player){return}
        let mouse = Display.current.mouse
        
            let x = mouse.x - Display.current.width/2 + game.camera.x - game.player.x 
            let y = mouse.y - Display.current.height/2 + game.camera.y - game.player.y
            
            let rotation = Math.atan2(y,x)
            game.client.addCommand(new Rotation(rotation))
            game.processedInput.rotation = rotation
        }
    Display.current.renderer.view.onmousedown = () => {
        game.processedInput.clicking = true
        game.client.addCommand(new Clicking(true))
        
        
        
    
    }
    Display.current.renderer.view.onmouseup = () => {
        game.processedInput.clicking = false
        game.client.addCommand(new Clicking(false))
    }   
    window.addEventListener("mousemove",onmousemove)
        }


function predictPlayer(player,game){
    if(!player){return}
    player.rotation = game.processedInput.rotation

    
    //if(game.joystick1){player.rotation = game.joystick1.angle} // change this
}

function detectMobile(){
    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){return true}
     else{return false}
}

function updateDayLight(delta,game){
    game.worldTime = (game.worldTime + delta) % game.worldTimeMax
    let red = Uti.interpolate(game.worldTime,game.worldTimeMax,
        [{p:0,v:100},{p:10,v:255},{p:20,v:250},{p:50,v:250},{p:60,v:200},{p:70,v:110},{p:100,v:100}])
    let green = Uti.interpolate(game.worldTime,game.worldTimeMax,
        [{p:0,v:110},{p:10,v:231},{p:20,v:250},{p:50,v:250},{p:60,v:160},{p:70,v:120},{p:100,v:110}])
    let blue = Uti.interpolate(game.worldTime,game.worldTimeMax,
        [{p:0,v:175},{p:10,v:193},{p:20,v:250},{p:50,v:250},{p:60,v:180},{p:70,v:180},{p:100,v:175}])
    
        /* tint = Uti.rgbToHex([100, 110, 170])
        tint = Uti.rgbToHex([255, 231, 183])
        tint = Uti.rgbToHex([250, 250, 250])
        tint = Uti.rgbToHex([200, 160, 180]) */
        
        let tint = Uti.rgbToHex([red, green, blue])
    Display.current.colorMatrix.tint(tint,false)
}