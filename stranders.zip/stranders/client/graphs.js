import { Display } from './Display';
import { Assets } from './Assets';
import * as PIXI from "pixi.js"
import { ItemList } from './../common/items';
import { Uti } from './../common/Uti';

const TWEEN = require('@tweenjs/tween.js')

class Graph extends PIXI.Container{
    constructor(data){
        super()
        this.entity = data
        this.x = this.entity.x
        this.y = this.entity.y
        this.scale.set(this.entity.scale || 6,this.entity.scale || 6)
        this.rotation = this.entity.rotation
        this.pivot.set(0.5,0.5)
        this.sortableChildren = true
        
    }
    update(delta,camera){
    
        this.x = this.entity.x// - camera.x + Display.current.width/2
        this.y = this.entity.y// - camera.y + Display.current.height/2
        this.rotation = this.entity.rotation
        /* this.x = this.entity.x
        this.y = this.entity.y */
    }
    animate(type){
        switch (type){
            case 1:
                this.animateHit()
                break;
            case 2: 
                this.animateAttack()
                break;
    }
} }

class Container extends PIXI.Container{
    constructor(){
        super()
        
    }}

class Sprite extends PIXI.Sprite{
    constructor(link){
        super(link)
        this.anchor.set(0.5,0.5)
        this.parentLayer = Display.current.layer
    
    }
    setRotatingPivot(x,y){
        this.pivot.set(x-this.texture.width/2,y-this.texture.height/2)
        this.position.set(x-this.texture.width/2,y-this.texture.height/2)
    }
}

export class Player extends Graph{
    constructor(data){
        super(data)

        //this.sprite = new Sprite("./client/assets/player.png")
        //this.addChild(this.sprite)

        this.body = new Container()
        this.head = new Sprite(Assets.textures.playerBody)
        this.head.zOrder = 5.5
        this.body.addChild(this.head)

        this.rightHand = new Sprite(Assets.textures.playerRightHand)
        this.body.addChild(this.rightHand)
        
        this.leftHand = new Sprite(Assets.textures.playerLeftHand)
        this.body.addChild(this.leftHand)
        this.leftHand.zOrder = 5.4
        
        this.rightHand.setRotatingPivot(3,15)
        
        this.leftHand.setRotatingPivot(3,this.leftHand.texture.height - 15)
        this.leftHand.texture.rotate = 8
        
        this.mainHand = this.rightHand;this.otherHand = this.leftHand
        this.leftHand.direction = 1;this.rightHand.direction = -1
       // this.rightHand.sortableChildren = true

        

        this.rightHand.zOrder = 5.4
        this.addChild(this.body)

        this.animateHit = animateHitTintRed
    }
    animateAttack(){
        if(this.holdItemName){ItemGraphList[this.holdItemName].animate(this);return}
            this.punch()
   
    }
    /* animateHit(){
        let red = {value: 255}
        new TWEEN.Tween(red)
        .to({value: 120}, 220)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {
            let tint = Uti.rgbToHex([255,red.value,red.value])
                applyTintToContainer(this,tint)

        })
        .repeat(1).yoyo(true)
        .start()
    } */
    
    punch(){
        let rotatingTween = new TWEEN.Tween(this.body)
        .to({rotation: this.mainHand.direction*Math.PI*0.1}, 200)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {})
        .repeat(1).yoyo(true)

        let punchingTween = new TWEEN.Tween(this.mainHand)
        .to({rotation: this.mainHand.direction*Math.PI*0.2}, 200)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {
        }).onComplete(() =>{})
        .repeat(1).yoyo(true)
        
        punchingTween.stop()
        punchingTween.start()
        rotatingTween.stop()
        rotatingTween.start()
        
        let temp = this.mainHand
        this.mainHand = this.otherHand
        this.otherHand = temp
    }
    update(){
        super.update()
        if(this.entity.selectedItemId != this.oldItemId){
            console.log(this.entity.selectedItemId)
            this.rightHand.removeChild(this.holdItem)
            if(this.entity.selectedItemId){
        this.holdItemName = ItemList.getItemById(this.entity.selectedItemId).name
        this.holdItem = new Sprite(Assets.textures[this.holdItemName])
        let itemGraph = ItemGraphList[this.holdItemName]
        this.holdItem.rotation = itemGraph.rotation
        this.holdItem.position.set(itemGraph.position.x, itemGraph.position.y)
        this.holdItem.scale.set(itemGraph.scale.x, itemGraph.scale.y)
        this.rightHand.addChild(this.holdItem)
        }

            this.oldItemId = this.entity.selectedItemId
    }
    }
}

export class Zombie extends Graph{
    constructor(data){
        super(data)
        this.scale.set(7,7)
        this.sprite = new Sprite(Assets.textures.zombie) // entity nid is not consistent now
        this.sprite.zOrder = 5
        this.animateHit = animateHitTintRed
        this.addChild(this.sprite)
    }
    animateAttack(){
        new TWEEN.Tween(this.sprite)
        .to({rotation: Math.PI*0.5}, 300)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {})
        .repeat(1).yoyo(true)
        .start()
    }
}

export class Tree extends Graph{
    constructor(data){
        super(data)
        let sprites = [Assets.textures.tree,Assets.textures.tree1]
        this.sprite = new Sprite(sprites[this.entity.nid % sprites.length]) // entity nid is not consistent now
        this.sprite.zOrder = 10
        this.addChild(this.sprite)
    }
    animate(rotation){
        console.log(rotation)
        let length = 2
        let dirX = Math.cos(rotation)
        let dirY = Math.sin(rotation)
        new TWEEN.Tween(this.sprite)
        .to({x:dirX*length,y:dirY*length}, 100)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {})
        .repeat(1).yoyo(true)
        .start()
    }
}

function animateHitTintRed(){let red = {value: 255}
new TWEEN.Tween(red)
.to({value: 120}, 220)
.easing(TWEEN.Easing.Quadratic.Out) 
.onUpdate(() => {
    let tint = Uti.rgbToHex([255,red.value,red.value])
        applyTintToContainer(this,tint)

})
.repeat(1).yoyo(true)
.start()
}

class ItemGraphList{constructor(){}}
ItemGraphList.sword = {rotation:Math.PI/4,position:{x:12,y:9.5},scale:{x:0.8,y:0.8},
animate: function(player){
    let rotatingTween = new TWEEN.Tween(player.body)
        .to({rotation: player.rightHand.direction*Math.PI*0.1}, 200)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {})
        .repeat(1).yoyo(true)

        let punchingTween = new TWEEN.Tween(player.rightHand)
        .to({rotation: player.rightHand.direction*Math.PI*0.2}, 200)
        .easing(TWEEN.Easing.Quadratic.Out) 
        .onUpdate(() => {
        }).onComplete(() =>{})
        .repeat(1).yoyo(true)
        
        punchingTween.stop()
        punchingTween.start()
        rotatingTween.stop()
        rotatingTween.start()
}}
ItemGraphList.item = {rotation:-Math.PI,position:{x:6,y:9.5},scale:{x:0.75,y:0.75},
animate: function(player){player.punch()}}
ItemGraphList.woodenSword = ItemGraphList.sword
ItemGraphList.wood = ItemGraphList.item
ItemGraphList.stone = ItemGraphList.item


////

function applyTintToContainer(container, tint) {
    container.children.forEach(child => {
      if (child instanceof PIXI.Sprite) {
        child.tint = tint;
      } else if (child instanceof PIXI.Container) {
        applyTintToContainer(child, tint);
      }
    });
  }
    