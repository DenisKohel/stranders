<!-- App.vue -->
<template>
  <div id="app">
   <UI></UI>
  </div>
</template>

<script>

import UI from './UI.vue';

export default {
  components: {
    UI
  },
};
</script>

<style>
img {   
   user-select: none;
   -moz-user-select: none;
   -webkit-user-drag: none;
   -webkit-user-select: none;
   -ms-user-select: none;
}

</style>
