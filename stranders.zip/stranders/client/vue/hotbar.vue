<template>
  <div id="hotbar">
    <div class="slot" :class="{ 'selected': selectedIndex === index }" v-for="(item, index) in inventory" :key="index">
      <img v-if="inventory[index] && inventory[index].item" :src="`./assets/${inventory[index].item.name}.png`" alt="" class="item" />
      <span class="item-count" v-if="inventory[index] && inventory[index].count > 1">
        {{ inventory[index].count }}
      </span>
    </div>
  </div>
</template>

<script>
import { eventer } from '../../common/eventer';

export default {
  data() {
    return {
      inventory: [{}, {}, {}, {}, {}, {}, {}],
      selectedIndex: 0,
    };
  },
  mounted() {
    eventer.on('playerInventory', (inv) => {
      this.inventory = [...inv];
    });

    eventer.on('selectSlot', (slotNumber) => {
      this.selectedIndex = slotNumber;
      
    });
  },
};
</script>




<style>
#hotbar{
  z-index: 3;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 35vw;
  transform: translate(-50%,50%);
  position: absolute;
  
  top: 83%;
  left: 50%;
}
.selected {
  background-color: rgba(255, 0, 0, 0.75);
  transform: translateY(-12%);
  scale: 105%;
}
.slot{
  z-index: 4;
  background-color: rgba(99, 99, 99, 0.25);
  width: 4.5vw;
  height: 4.5vw;
  border-radius: 12%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.item{
  width: 65%;
  height: 65%;
  margin-bottom: 15%;
  image-rendering: pixelated;
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
  filter: drop-shadow(0.5px 2px 1px rgb(45, 45, 45))
}

.item-count {
  
  position:relative;
  text-align-last: right;
  bottom: -15%; /* Adjust this value to position the item count below the slot */
  left: -75%;
  width: 0;
  height: 0;
   /* Change this value to set the color of the item count */
  font-size: 1.25vw; /* Adjust this value to change the font size of the item count */
  
  filter: drop-shadow(2px 2px 1px rgb(61, 61, 61))
}
</style>
