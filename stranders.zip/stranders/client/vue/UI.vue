<!-- App.vue -->
<template>
  <div id="UI">
    
    <hotbar></hotbar>
    <div id = "bars">
<!--       <Bar v-bind:currentValue="health" v-bind:maxValue="maxHealth" color="lightcoral"></Bar>
 -->      <Container :maxValue="maxHealth" :currentValue="health" :valuePerOne="5" :containerWidth = "12" :containerHeight = "1.75" color = "rgb(255,90,125)"></Container>
    </div>

   
  </div>
</template>

<script>
import hotbar from './hotbar.vue'
import Bar from "./Bar.vue"
import Container from './Container.vue';
import { eventer } from '../../common/eventer';
export default {

  components: {
    hotbar,
    Bar,
    Container,
  },
  data(){
    return {
    health: 25,
    maxHealth: 25,
  
    }
  },
  mounted() {
    // console.log("number of eventers")
    eventer.on('playerHp', (e) => {
      this.health = e.hp;
      this.maxHealth = e.maxHp;
    });

  },
};
</script>

<style>
#UI{
  pointer-events: none;
  position: fixed;
  top: 0%;
  left: 0%;
  -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    z-index: 2;
    font-size: 1.25vw; /* Adjust this value to change the font size of the item count */
    width: 100vw;
    height: 100vh;

    font-family: Arial, Helvetica, sans-serif;
    white-space: nowrap;
  font-weight: bold;
  color: #ffffff;
}

#bars{
  position: absolute;
  display: flex;
  flex-direction: row;
  width: 100vw;
  height: 100vw;
  top: 81%;
  left: 28.5%;
}



</style>
