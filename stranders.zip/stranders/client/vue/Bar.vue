<template>
    <div class="bar-container" v-bind:style="{borderColor: color}">
        <div class="bar-text">{{ currentValue }} / {{ maxValue }}</div>
        <div class="bar" v-bind:style="{backgroundColor: color, width: percentage + '%'}"></div>
        <div
            class="notch"
            v-for="index in maxValue - 1"
            :key="index"
            :style="{left: (100 / maxValue) * (index + 1) + '%'}"
        ></div>
    </div>
</template>

<script>
export default {
    data() {},
    props: {
        currentValue: {
            type: Number,
            default: 20
        },
        maxValue: {
            type: Number,
            default: 20
        },
        color: {
            type: String,
        }
    },
    computed: {
        percentage() {
            return (this.currentValue / this.maxValue) * 100;
        }
    }
}
</script>

<style>
.bar {
    position: absolute;
    left: 0%;
    top: 0%;
    z-index: 2;
    width: 20%;
    height: 100%;
    transition: width 0.5s ease;
}

.bar-container {
    position: relative;
    height: 1.25%;
    width: 11%;
    border: solid;
    border-width: 0.2vw;
    border-radius: 4%;
    z-index: 3;
}

.bar-text {
  position: absolute;
  text-align: center;
  left: 0%;
  top: -3%;
  width: 100%;
  height: 100%;
  z-index: 4;
}

.notch {
    position: absolute;
    top: 0%;
    height: 100%;
    width: 2px;
    z-index: 4;
    background-color: transparent;
}

.notch::before {
    content: "";
    position: absolute;
    left: 50%;
    top: 0%;
    height: 100%;
    width: 1px;
    background-color: rgba(255, 255, 255, 0.5);
    transform: translateX(-50%);
}


</style>
