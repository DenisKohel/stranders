<template>
  <div class="container">
    <div
      v-for="(segment, index) in maxSegments"
      :key="'segment-' + index"
      class="segment"
      :style="index >= currentSegments ? { ...segmentStyles, ...emptySegmentStyles } : { ...segmentStyles, ...(index === currentSegments - 1 ? lastSegmentStyles : {}) }"
    >
    </div>
  </div>
</template>



  
  <script>
  
  export default {
    props: {
      maxValue: {
        type: Number,
        required: true,
      },
      currentValue: {
        type: Number,
        required: true,
      },
      valuePerOne: {
        type: Number,
        default: 5
      },
      containerWidth: {
        type: Number,
        default: 12
      },
      containerHeight: {
        type: Number,
        default: 1.75
      },
      color: {
        type: String,
        default: "white"
      }
    },
    computed: {
      maxSegments() {
        return Math.ceil(this.maxValue / this.valuePerOne)
      },
      currentSegments(){
        return Math.ceil(this.currentValue / this.valuePerOne)
      },
      segmentWidth(){
        return this.containerWidth / (this.maxSegments / 5)
      },
      lastSegmentStyles(){
        let segmentIndex = Math.ceil(this.currentValue / this.valuePerOne)
        let valueInLastSegment = this.currentValue - (this.valuePerOne*(segmentIndex - 1))
        //console.log(segmentIndex - 1,this.valuePerOne,this.currentValue)
        let gradientWidth = /* this.segmentWidth *  */(valueInLastSegment / this.valuePerOne) * 100
        return {
          
          //width: ((this.currentValue % 5) / 5) * 12 + "%"
          
          backgroundImage: `linear-gradient(
      to right,
      ${this.color} 0%,
      ${this.color} ${gradientWidth}%,
      rgba(0, 0, 255, 0) ${gradientWidth}%
    )`
        }
      },
      segmentStyles(){
        const gradientWidth = 100
        return{
          width: this.segmentWidth + "%",
          height: this.containerHeight + "%",
          border: `solid ${this.color}`,
          backgroundImage: `linear-gradient(
      to right,
      ${this.color} 0%,
      ${this.color} ${gradientWidth}%,
      rgba(0, 0, 255, 0) ${gradientWidth}%
    )`
        }
      },
      emptySegmentStyles(){
        const gradientWidth = 0
    
        return{
          
          //top: 0.25 + "%",
          backgroundImage: `linear-gradient(
      to right,
      ${this.color} 0%,
      ${this.color} ${gradientWidth}%,
      rgba(0, 0, 255, 0) ${gradientWidth}%
    )`
        }
      }
    },
  };
  </script>
  
  <style scoped>
.container {
  display: flex;
  gap: 2px;
  width: 20%;
  position: relative;
}

.segment {
  opacity: 76%;
  position: relative;
  transition: width 0.5s ease;
  border-radius: 12%;
}

</style>

