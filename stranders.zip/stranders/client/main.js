
import { Display } from './Display';
import Input from './Input';
import { Client } from './Client';
import { Game } from './Game';
import { Assets } from './Assets';

import { createApp } from 'vue';
import App from './vue/App.vue';

const app = createApp(App);
app.mount('#app');

const imagePaths = [
    "./assets/playerBody.png",
    "./assets/playerRightHand.png",
    "./assets/playerLeftHand.png",
    "./assets/tree.png",
    "./assets/tree1.png",
    "./assets/woodenSword.png",
    "./assets/wood.png",
    "./assets/stone.png",
    "./assets/zombie.png",
]

async function run(){
const display = new Display(0x103019,1920,1080)
const input = new Input()
await Assets.loadTextures(imagePaths)

const game = new Game()


//renderer.init()

let tick = 0
let previous = performance.now()
const loop = function() {
    window.requestAnimationFrame(loop)
    const now = performance.now()
    const delta = (now - previous) / 1000
    previous = now
    tick++

    game.update(delta//, tick, now
        )
    display.draw(game.graphs)
    display.undraw(game.graphsToDelete)
    game.graphsToDelete = []
}

loop()
}
run()