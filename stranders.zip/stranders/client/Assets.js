import * as PIXI from "pixi.js"

export class Assets{constructor(){}
static textures = {}
static async loadTextures(paths){
    for(let i in paths){
        let imageFile = paths[i].split("/").at(-1)
        let name = imageFile.split(".").at(0)
Assets.textures[name] = await PIXI.Assets.loader.load(paths[i])
    }
}}