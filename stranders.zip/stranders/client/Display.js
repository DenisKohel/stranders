import {Layer, Stage } from "@pixi/layers"
import * as PIXI from "pixi.js"
export class Display extends PIXI.Application{
    constructor(background,width,height){
    Display.current
    if (Display.current){return Display.current}

    let stage = new Stage();
    super({background: background,width: width,height: height})
    
    this.stage = stage
    this.width = width
    this.height = height
    this.aspectRatio = this.width/this.height
    PIXI.Renderer.type = PIXI.RENDERER_TYPE.WEBGL
   PIXI.BaseTexture.defaultOptions.scaleMode = PIXI.SCALE_MODES.NEAREST
   PIXI.settings.antialias = false
    this.renderer.view.style.imageRendering = "pixelated"
    this.renderer.view.style.imageRendering = "-moz-crisp-edges"
    this.renderer.view.style.imageRendering = "crisp-edges"

    this.renderer.view.style.position = "absolute"
    this.renderer.view.style.top = "50%"
    this.renderer.view.style.left = "50%"
    this.renderer.view.style.transform = "translate(-50%, -50%)"
    this.renderer.view.style.zIndex = "1"

    document.body.style.overflow = "hidden"
    document.body.style.margin = "0px"
    document.body.style.padding = "0px"

    document.body.appendChild(this.view)
    
    // TODO: clientWidth / height working on mobile
    this.resize = function(){
        if(window.innerWidth/window.innerHeight > this.aspectRatio){
            this.resizedWidth = window.innerWidth
            this.resizedHeight = window.innerWidth / this.aspectRatio
        }
        else{
            this.resizedWidth = window.innerHeight * this.aspectRatio
            this.resizedHeight = window.innerHeight
        }
        this.renderer.view.style.width = "" + this.resizedWidth + "px"
        this.renderer.view.style.height = "" + this.resizedHeight + "px"   
    }
    this.resize()
    window.addEventListener("resize",this.resize.bind(this))

    this.stage.sortableChildren = true

    this.layer = new Layer();
    this.layer.group.enableSort = true;
    this.layer.enableSort = true;
    this.stage.addChild(this.layer);

   this.stage.position.set(width/2,height/2)
   this.stage.pivot.set(width/2, height/2);
    this.mouse = this.renderer.events.rootPointerEvent.global
    //this.stage.interactive = true
    Display.current= this
    
    this.colorMatrix = new PIXI.ColorMatrixFilter();
    this.stage.filters = [this.colorMatrix];
    
    this.backgroundImg = PIXI.Sprite.from("./assets/backgroundImg.png")
    this.backgroundImg.width = 12000
    this.backgroundImg.height = 12000
    this.backgroundImg.zOrder = 0
    this.backgroundImg.parentLayer = this.layer
    this.stage.addChild(this.backgroundImg)

    }
    draw(graphs){
        for (let i in graphs){this.stage.addChild(graphs[i])}
    }
    undraw(graphsToDelete){for (let i in graphsToDelete){this.stage.removeChild(graphsToDelete[i])}
}

}