import { Uti } from "../common/Uti.js";
import * as Entities from "../common/entities.js"
import { Grid } from './Grid';
import { createNoise2D } from 'simplex-noise';
export class WorldGenerator{constructor(game){
    this.game = game
}

generate(){
    this.noise = createNoise2D()
    
  for (let i = 0;i <= 20; i++){
      this.spawn(new Entities.Zombie(),this.game.border)
  }
    for (let i = 0;i <= 150; i++){
        this.spawn(new Entities.Tree(),this.game.border)
    }
    
}
spawn(entity,area){
  
  

  for(let k = 0; k <= 100; k++){
    let x = Math.random() * area.width
    let y = Math.random() * area.height
    if(this.testMap(x,y,entity) && this.checkSpawnBlock(x,y,entity)){
      entity.setPos(x,y)
      this.game.addEntity(entity)
      return true
    }
  }
  console.log("could not spawn an entity")
  return false
    
}
checkSpawnBlock(x,y,entity){
  let nearbyEntities = this.game.getNear({x: x, y: y})
    if(nearbyEntities.length == 0){
    return true
    }
    for(let i in nearbyEntities){
      let near = nearbyEntities[i]
      let distance = Uti.getDistance(near,{x: x, y: y})
      //console.log(distance," ",{x: near.x, y: near.y}," ",{x: x, y: y})
      if(distance < near.spawnBlockRadius+entity.spawnBlockRadius){return false}
    }
    return true
}
testMap(x,y,entity){
  let chance = (this.noise(x,y) + 1)/2
  
  if(chance < 0.1){return true}
  else{return false}
}
}



