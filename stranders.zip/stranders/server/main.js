
import { GameServer } from './GameServer';
import nengiConfig from "../common/nengiConfig.js"
import { Fps } from './../common/messages';

const game = new GameServer()

const hrtimeMs = function() {
    const time = process.hrtime()
    return time[0] * 1000 + time[1] / 1000000
}

let tick = 0
let previous = hrtimeMs()
const tickLengthMs = 1000 / nengiConfig.UPDATE_RATE
const tickLength = 1 / nengiConfig.UPDATE_RATE

let sum = 0; let average = 0; let n = 0; let fps = 0
const loop = function() { // TODO: fix the timestep
    const now = hrtimeMs()
    if (previous + tickLengthMs <= now) {
        const delta = (now - previous) / 1000
        previous = now
        tick++
        
        const start = hrtimeMs() // uncomment to benchmark
        game.update(delta, tick, Date.now())
        const stop = hrtimeMs()
        //console.log('update took', stop-start, 'ms')
        n++
        sum += (stop - start)

    }

    if (hrtimeMs() - previous < tickLengthMs - 4) {
        setTimeout(loop)
    } else {
        setImmediate(loop)
    }
}
setInterval(() =>{
average = sum / n
fps = 1000/average
game.instance.messageAll(new Fps(fps))
n = 0;sum = 0
},1000)
loop()
