import nengi from "nengi"
import {Chat,Identity, InventoryChange, PlayerHp} from "../common/messages.js"
import nengiConfig from "../common/nengiConfig.js"
import Instance from './Instance';
import * as Entities from "../common/entities.js"
import { Grid } from "./Grid.js";
import { eventer } from "../common/eventer.js";
import { Player } from "../common/entities.js";
import { WorldGenerator } from "./WorldGenerator.js";


export class GameServer{
constructor(){
    
    const border = this.border = {width: 11520/1.25, height:6480/1.25}
    const instance = this.instance = new Instance(8079)
    this.entities = instance.entities.array
    this.actors = [{update:function(){return}}]
    this.entitiesToDelete = []
    this.grid = new Grid(border, 648)
    this.worldGenerator = new WorldGenerator(this)
    this.worldGenerator.generate()
    
    
    

    instance.on("connect",({client})=>{
        let player = new Entities.Player()
        player.x = Math.random()*border.width
        player.y = Math.random()*border.height
        player.x = this.border.width/2
        player.y = this.border.height/2
        client.view = {
            x: player.x,
            y: player.y,
            halfWidth: border.width,
            halfHeight: border.height // change to the screen dimensions
        }

        client.player = player
        player.client = client
        this.addEntity(player)
        this.instance.addEntity(player)
        instance.message(new Identity(client.player.nid,border),client)
    })
    instance.on("disconnect",(client)=>{
        this.deleteEntity(client.player) // TODO: Make list and remove entities in update loop
    })
    instance.on("command::PlayerInput",({command,client,tick})=>{
        client.player.control.dir = {x:command.dirX,y:command.dirY}
    //client.player.delta = command.delta
                })
    instance.on("command::Rotation",({command,client,tick})=>{client.player.rotation = command.rotation})
    instance.on("command::Clicking",({command,client,tick})=>{client.player.clicking = command.clicking})
    instance.on("command::SelectSlot",({command,client,tick})=>{client.player.selectSlot(command.slot)})

    eventer.on("death",(e)=>{this.deleteEntity(e)})
    eventer.on("inventoryChange",(e)=>{
        let player = e.player
        let slot = player.inventory.slots[e.slot]
        let id; let count
        if(slot){id = slot.item.id;count = slot.count}
        else{id = 0; count = 0}
        this.instance.message(new InventoryChange(e.slot,id,count),player.client)
    })
    eventer.on("hpChange",(e)=>{if(e instanceof Player){
        this.instance.message(new PlayerHp(e.hp,e.maxHp),e.client)
    }})
}
addEntity(entity){
//this.instance.addEntity(entity)
this.grid.insert(entity)
}
deleteEntity(entity){
    entity.isAlive = false
    this.grid.remove(entity)
    //this.instance.removeEntity(entity)
    
    
}


update(delta){
    
    this.instance.emitCommands()
    
    
    let entities = this.getLoadedEntities()
   
    


    this.instance.entities.array.forEach((entity) => {
        if(!entities.has(entity)){this.instance.removeEntity(entity)}
    })

    entities.forEach((entity) => {
        
        if(!this.instance.entities.array.includes(entity)){
            this.instance.addEntity(entity)
        }
    })

   this.actors = Array.from(entities).filter(entity => entity.updatable == true)
    
   
    for (let i in this.actors){let entity = this.actors[i];entity.update(delta,this)
}
    this.instance.clients.forEach(client => {
        client.view.x = client.player.x
        client.view.y = client.player.y
    })
   
    
    
    /* for(let i in this.entitiesToDelete){
        let entity = this.entitiesToDelete[i]
        this.instance.removeEntity(entity)
    } */
    this.instance.update()
}


getNear(entity){
    return this.grid.getNearEntities(entity,1)
}
getLoadedEntities(){
    const loadDistance = 8
    let entities = new Set()
    for (let i in this.instance.clients.array){
        let player = this.instance.clients.array[i].player
        if(player){
        let nearEntities = this.grid.getNearEntities(player,loadDistance)
        nearEntities.forEach((entity) => entities.add(entity))
        
        }
    }
return entities
}


}

const logOnce = (function() {
    let executed = false;
    return function(message) {
        if (!executed) {
            executed = true;
            console.log(message);
        }
    };
})();


