
import { eventer } from './../common/eventer';
import { Uti } from './../common/Uti';
export class Grid{
    constructor(border,chunkSize){
this.width = border.width
this.height = border.height
this.chunkSize = chunkSize
this.chunks = []


for(let i = -6;i - 6 <= this.width / this.chunkSize;i++){
    this.chunks[i] = []
    for(let j = -6;j - 6 <= this.height / this.chunkSize;j++){
        this.chunks[i][j] = []}}
        
        eventer.on("posChanged",(entity)=>{
            if(entity.chunkX == undefined){return}
            this.update(entity)})
    }
insert(entity){
let index = this.getIndex(entity)
entity.gid = Math.random() // better ID function
this.chunks[index[0]][index[1]][entity.gid] = entity
entity.chunkX = index[0]; entity.chunkY = index[1]
}
remove(entity){
delete this.chunks[entity.chunkX][entity.chunkY][entity.gid]
}
getIndex({x,y}){
    let i = Math.floor(x / this.chunkSize)
    let j = Math.floor(y / this.chunkSize)
    return [i,j]
}
update(entity){
let index = this.getIndex(entity)
if(index[1] !== entity.chunkY || index[0] !== entity.chunkX){

this.remove(entity)
this.chunks[index[0]][index[1]][entity.gid] = entity
entity.chunkX = index[0]; entity.chunkY = index[1]
/* console.log(entity.x + "," + entity.y + " entity moved to " + index[0] + " " + index[1])
 */


}
}

getNearChunks(entity,size){
    let chunkX; let chunkY
    if(entity.chunkX){chunkX = entity.chunkX;chunkY = entity.chunkY}
    else{[chunkX, chunkY] = this.getIndex(entity)}
    let chunks = []
    for(let i = -size;i <= size;i++){
        for(let j = -size;j <= size;j++){
            chunks.push(this.chunks[chunkX + i][chunkY + j])
        }
    }
    return chunks
}

getNearEntities(entity,size){
    return Uti.flattenArray(this.getNearChunks(entity,size))

    /* let chunks = this.getNearChunks(entity,size)
    let entities = []
    for (let a in chunks){
        for(let b in chunks[a]){entities.push(chunks[a][b])}
    }
    return entities */
    

}

getNeighborChunks({chunkX,chunkY}){
return this.chunks[chunkX][chunkY]
}
}